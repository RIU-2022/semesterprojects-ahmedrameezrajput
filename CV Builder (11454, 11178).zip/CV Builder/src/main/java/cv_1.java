import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.itextpdf.awt.geom.Rectangle;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.JEditorPane;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.awt.SystemColor;
import javax.swing.JButton;

public class cv_1 extends JFrame {
	public JLabel cv1_expSdate;
	public JLabel cv1_expEdate;
	public JLabel cv1_eduSdate;
	public JLabel cv1_eduEdate;
	public JLabel cv1_name_1;
	public JLabel cv1_prof;
	public JLabel cv1_phone;
	public JLabel cv1_email;
	public JEditorPane cv1_summary;
	public JLabel cv1_jobtitle;
	public JLabel cv1_address;
	public JTextPane cv1_expPane;
	public JLabel cv1_degree;
	public JLabel cv1_schname;
	public JLabel cv1_skill1;
	public JLabel cv1_skill2;
	public JLabel cv1_skill3;
	public JLabel cv1_skill4;

	private  JPanel contentPane;


	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
                    try {
                        cv_1 frame = new cv_1();
                        frame.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
	}

	/**
	 * Create the frame.
	 */
	public cv_1() {
		setTitle("CV Buider");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 904, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(0, 0, 0));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
		JLabel lblNewLabel_10 = new JLabel("PDF");
		lblNewLabel_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String expSdate=cv1_expSdate.getText();
				String expEdate=cv1_expEdate.getText();
				String eduSdate= cv1_eduSdate.getText();
				String eduEdate= cv1_eduEdate.getText();
				String name= cv1_name_1.getText();
				String prof= cv1_prof.getText();
				String phone= cv1_phone.getText();
				String email= cv1_email.getText();
				String summary= cv1_summary.getText();
				String jobtitle=cv1_jobtitle.getText();
				String address= cv1_address.getText();
				String expPane= cv1_expPane.getText();
				String degree=cv1_degree.getText();
				String schname=cv1_schname.getText();
				String skill1=cv1_skill1.getText();
				String skill2=cv1_skill2.getText();
				String skill3=cv1_skill3.getText();
				String skill4=cv1_skill4.getText();
				
				String path="H:\\javapdf\\cvpdf";
				Document document=new Document();
				try {
					PdfWriter.getInstance(document, new FileOutputStream(path));
					
					document.open();
					Paragraph paraa=new Paragraph("Asif Shah",FontFactory.getFont(FontFactory.TIMES,1));
					Paragraph paraa1=new Paragraph("     ");
					Paragraph paraa2=new Paragraph("     ");
					Paragraph para=new Paragraph("                    "+name,FontFactory.getFont(FontFactory.TIMES_BOLD,18));
				   Paragraph para1=new Paragraph("                         "+prof,FontFactory.getFont(FontFactory.TIMES,14)); 
				   Paragraph para7=new Paragraph("                                 "+jobtitle,FontFactory.getFont(FontFactory.TIMES_BOLD,14));
				   Paragraph para8=new Paragraph("                                  "+address); 
				  Paragraph para12=new Paragraph("                                 "+degree,FontFactory.getFont(FontFactory.TIMES_BOLD,14));
				  Paragraph para13=new Paragraph("                                  "+schname); 
				  Paragraph para16=new Paragraph("                                  "+skill1);
				  Paragraph para17=new Paragraph("                                  "+skill2);
				  Paragraph para18=new Paragraph("                                  "+skill3);
				  Paragraph para19=new Paragraph("                                  "+skill4);
					
					PdfPTable table=new PdfPTable(new float[] {1,4,1,4});
					table.setWidthPercentage(75);
					Paragraph para2=new Paragraph(phone);
					Paragraph para3=new Paragraph(email);
					
					PdfPTable table1=new PdfPTable(1);
					table1.setWidthPercentage(75);
					Paragraph para4=new Paragraph(summary,FontFactory.getFont(FontFactory.TIMES,12));
					
					PdfPTable tableexp=new PdfPTable(new float[] {3,2,19});
					tableexp.setWidthPercentage(100);
					Paragraph para5=new Paragraph(expSdate+" "+expEdate);
					Paragraph para6=new Paragraph("Experience ",FontFactory.getFont(FontFactory.TIMES_BOLD,16));
					
					PdfPTable table2=new PdfPTable(1);
					table2.setWidthPercentage(57);
					Paragraph para9=new Paragraph(expPane,FontFactory.getFont(FontFactory.TIMES,12));
					
					PdfPTable tableedu=new PdfPTable(new float[] {3,2,19});
					tableedu.setWidthPercentage(100);
					Paragraph para10=new Paragraph(eduSdate+" "+eduEdate);
					Paragraph para11=new Paragraph("Education ",FontFactory.getFont(FontFactory.TIMES_BOLD,16));
					
					PdfPTable tableskill=new PdfPTable(new float[] {3,2,19});
					tableskill.setWidthPercentage(100);
					Paragraph para14=new Paragraph(" ");
					Paragraph para15=new Paragraph("Skill ",FontFactory.getFont(FontFactory.TIMES_BOLD,16));
					
					
					try {
						Image phoneicon=Image.getInstance("icons/phone_gjsj5bhj9ft9_32.png");
						Image emailicon=Image.getInstance("icons/email_zx3v242m24hg_32.png");
						Image degreeicon=Image.getInstance("icons/degree_hcro90v93q0y_32.png");
						Image expicon=Image.getInstance("icons/user_experience_8h1od462kf5h_32.png");
						Image skillicon=Image.getInstance("icons/skills_mrheq53yz4jj_32.png");
						
						//table.addCell(new PdfPCell( phoneicon));
						PdfPCell cl1=new PdfPCell(phoneicon);
						cl1.setBorder(Rectangle.OUT_TOP);
						PdfPCell cl2=new PdfPCell(para2);
						cl2.setBorder(Rectangle.OUT_TOP);
						PdfPCell cl3=new PdfPCell(emailicon);
						cl3.setBorder(Rectangle.OUT_TOP);
						PdfPCell cl4=new PdfPCell(para3);
						cl4.setBorder(Rectangle.OUT_TOP);
						 
						 table.addCell(cl1);
						 table.addCell(cl2);
						 table.addCell(cl3);
						 table.addCell(cl4);
						
//						table.addCell(new PdfPCell( phoneicon));
//						table.addCell(new PdfPCell( para2));
//					    table.addCell(new PdfPCell( emailicon));
//					    table.addCell(new PdfPCell( para3));
					    
						 PdfPCell cl5=new PdfPCell(para4);
						 cl5.setBorder(Rectangle.OUT_TOP);
						 cl5.setBackgroundColor(BaseColor.CYAN);
						 cl5.setBorder(Rectangle.OUT_BOTTOM);
						 cl5.setBorder(Rectangle.OUT_RIGHT);
						 cl5.setBorder(Rectangle.OUT_LEFT);
						 
						 table1.addCell(cl5);
						 
					   // table1.addCell(new PdfPCell( para4));
					    
						
						 PdfPCell cl6=new PdfPCell(para5);
						 cl6.setBackgroundColor(BaseColor.CYAN);
						 cl6.setBorder(Rectangle.OUT_TOP);
						 cl6.setBorder(Rectangle.OUT_BOTTOM);
						 PdfPCell cl7=new PdfPCell(expicon);
						 cl7.setBorder(Rectangle.OUT_TOP);
						 PdfPCell cl8=new PdfPCell(para6);
						 cl8.setBorder(Rectangle.OUT_TOP);
						 
						 tableexp.addCell(cl6);
						 tableexp.addCell(cl7);
						 tableexp.addCell(cl8);
						 
//						tableexp.addCell(new PdfPCell( para5));
//						tableexp.addCell(new PdfPCell( expicon));
//					    tableexp.addCell(new PdfPCell( para6));
					    
						 PdfPCell cl9=new PdfPCell(para9);
						 
						 cl9.setBorder(Rectangle.OUT_TOP);
						 table2.addCell(cl9);
						 
					   // table2.addCell(new PdfPCell( para9));
					    
						 PdfPCell cl10=new PdfPCell(para10);
						 cl10.setBackgroundColor(BaseColor.CYAN);
						 cl10.setBorder(Rectangle.OUT_TOP);
						 cl10.setBorder(Rectangle.OUT_BOTTOM);
						 PdfPCell cl11=new PdfPCell(degreeicon);
						 cl11.setBorder(Rectangle.OUT_TOP);
						 PdfPCell cl12=new PdfPCell(para11);
						 cl12.setBorder(Rectangle.OUT_TOP);
						 
						 tableedu.addCell(cl10);
						 tableedu.addCell(cl11);
						 tableedu.addCell(cl12);
						 
//					    tableedu.addCell(new PdfPCell( para10));
//						tableedu.addCell(new PdfPCell( degreeicon));
//					    tableedu.addCell(new PdfPCell( para11));
					    
						 PdfPCell cl13=new PdfPCell(para14);
						 cl13.setBorder(Rectangle.OUT_TOP);
						 cl13.setBorder(Rectangle.OUT_BOTTOM);
						 PdfPCell cl14=new PdfPCell(skillicon);
						 cl14.setBorder(Rectangle.OUT_TOP);
						 PdfPCell cl15=new PdfPCell(para15);
						 cl15.setBorder(Rectangle.OUT_TOP);
						 
						 tableskill.addCell(cl13);
						 tableskill.addCell(cl14);
						 tableskill.addCell(cl15);
						 
//					    tableskill.addCell(new PdfPCell( skillicon));
//					    tableskill.addCell(new PdfPCell( para14));
//					    tableskill.addCell(new PdfPCell( para15));
					    
						
					} catch (MalformedURLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					
					
					document.add(para);
					document.add(para1);
					document.add(paraa1);
					document.add(paraa2);
					document.add(table);
					document.add(table1);
					document.add(paraa1);
					document.add(tableexp);
					document.add(para7);
					document.add(para8);
					document.add(paraa1);
					document.add(table2);
					document.add(paraa1);
					document.add(tableedu);
					document.add(para12);
					document.add(para13);
					document.add(paraa1);
					document.add(tableskill);
					document.add(para16);
					document.add(para17);
					document.add(para18);
					document.add(para19);
					
				} catch (FileNotFoundException | DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null, "PDF downloaded in H:\\\\javapdf\\\\cvpdf");
				document.close();
//				Mail mail=new Mail();
//				mail.sendmail();
				
			}
		});
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\dowload_xsk45of8as6a_32.png"));
		lblNewLabel_10.setBounds(256, 13, 65, 39);
		panel.add(lblNewLabel_10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 63, 892, 668);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 120, 668);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		 cv1_expSdate = new JLabel("New label");
		 cv1_expSdate.setHorizontalAlignment(SwingConstants.TRAILING);
		cv1_expSdate.setForeground(new Color(0, 255, 255));
		cv1_expSdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_expSdate.setBounds(12, 269, 96, 27);
		panel_2.add(cv1_expSdate);
		
		 cv1_eduSdate = new JLabel("New label");
		 cv1_eduSdate.setHorizontalAlignment(SwingConstants.TRAILING);
		cv1_eduSdate.setForeground(new Color(0, 255, 255));
		cv1_eduSdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_eduSdate.setBounds(12, 416, 96, 27);
		panel_2.add(cv1_eduSdate);
		
	    cv1_expEdate = new JLabel("New label");
		cv1_expEdate.setHorizontalAlignment(SwingConstants.TRAILING);
		cv1_expEdate.setForeground(new Color(0, 255, 255));
		cv1_expEdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_expEdate.setBounds(12, 287, 96, 27);
		panel_2.add(cv1_expEdate);
		
	    cv1_eduEdate = new JLabel("New label");
		cv1_eduEdate.setHorizontalAlignment(SwingConstants.TRAILING);
		cv1_eduEdate.setForeground(new Color(0, 255, 255));
		cv1_eduEdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_eduEdate.setBounds(12, 433, 96, 27);
		panel_2.add(cv1_eduEdate);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(120, 0, 772, 668);
		panel_1.add(panel_3);
		panel_3.setLayout(null);
		
		 cv1_name_1 = new JLabel("New label");
		cv1_name_1.setLabelFor(this);
		cv1_name_1.setForeground(new Color(0, 51, 102));
		cv1_name_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		cv1_name_1.setBounds(12, 13, 258, 42);
		cv1_name_1.setText("");
		panel_3.add(cv1_name_1);
		
		 cv1_prof = new JLabel("New label");
		 cv1_prof.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_prof.setForeground(new Color(0, 51, 102));
		cv1_prof.setBounds(12, 47, 206, 25);
		panel_3.add(cv1_prof);
		
		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\phone_gjsj5bhj9ft9_32.png"));
		lblNewLabel_9.setBounds(12, 85, 40, 33);
		panel_3.add(lblNewLabel_9);
		
		 cv1_phone = new JLabel("New label");
		cv1_phone.setForeground(new Color(0, 0, 0));
		cv1_phone.setBounds(51, 89, 201, 21);
		panel_3.add(cv1_phone);
		
		 cv1_email = new JLabel("New label");
		cv1_email.setBounds(350, 89, 201, 21);
		panel_3.add(cv1_email);
		
		 cv1_summary = new JEditorPane();
		 cv1_summary.setForeground(new Color(0, 0, 0));
		 cv1_summary.setEditable(false);
		 cv1_summary.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_summary.setBackground(new Color(0, 255, 255));
		cv1_summary.setBounds(12, 138, 701, 113);
		panel_3.add(cv1_summary);
		
		JLabel lblNewLabel_11 = new JLabel("Experience");
		lblNewLabel_11.setForeground(new Color(0, 51, 102));
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_11.setBounds(51, 264, 159, 36);
		panel_3.add(lblNewLabel_11);
		
		JLabel lblNewLabel_11_1 = new JLabel("Education");
		lblNewLabel_11_1.setForeground(new Color(0, 51, 102));
		lblNewLabel_11_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_11_1.setBounds(51, 413, 159, 36);
		panel_3.add(lblNewLabel_11_1);
		
		JLabel lblNewLabel_11_2 = new JLabel("Skills");
		lblNewLabel_11_2.setForeground(new Color(0, 51, 102));
		lblNewLabel_11_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_11_2.setBounds(51, 520, 159, 36);
		panel_3.add(lblNewLabel_11_2);
		
		 cv1_jobtitle = new JLabel("New label");
		 cv1_jobtitle.setFont(new Font("Tahoma", Font.BOLD, 15));
		cv1_jobtitle.setForeground(new Color(0, 51, 102));
		cv1_jobtitle.setBounds(51, 300, 201, 21);
		panel_3.add(cv1_jobtitle);
		
		 cv1_expPane = new JTextPane();
		 cv1_expPane.setEditable(false);
		cv1_expPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_expPane.setText("Kindly clear your pending dues before your Mid-term exams to avoid any inconvenience on the day. Admit cards are invalid without clearance of pending dues. Students with any kind of pending dues will not be allowed in the exam hall. Students can download their fee challans from FIORI APP themselves. Students can approach Fee & Dues front desks during office working hours to receive their challans. ");
		cv1_expPane.setBackground(new Color(255, 255, 255));
		cv1_expPane.setBounds(51, 343, 391, 68);
		panel_3.add(cv1_expPane);
		
		 cv1_degree = new JLabel("New label");
		 cv1_degree.setForeground(new Color(0, 64, 128));
		cv1_degree.setFont(new Font("Tahoma", Font.BOLD, 15));
		cv1_degree.setBounds(51, 446, 528, 36);
		panel_3.add(cv1_degree);
		
		 cv1_schname = new JLabel("New label");
		 cv1_schname.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cv1_schname.setBounds(61, 484, 342, 25);
		panel_3.add(cv1_schname);
		
		 cv1_skill1 = new JLabel("New label");
		cv1_skill1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cv1_skill1.setBounds(51, 564, 391, 25);
		panel_3.add(cv1_skill1);
		
		 cv1_skill2 = new JLabel("New label");
		cv1_skill2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cv1_skill2.setBounds(51, 589, 391, 25);
		panel_3.add(cv1_skill2);
		
		 cv1_skill3 = new JLabel("New label");
		cv1_skill3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cv1_skill3.setBounds(51, 616, 391, 25);
		panel_3.add(cv1_skill3);
		
		 cv1_skill4 = new JLabel("New label");
		cv1_skill4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cv1_skill4.setBounds(51, 643, 391, 25);
		panel_3.add(cv1_skill4);
		
		JLabel lblNewLabel_9_1 = new JLabel("");
		lblNewLabel_9_1.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\email_zx3v242m24hg_32.png"));
		lblNewLabel_9_1.setBounds(310, 85, 40, 33);
		panel_3.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("");
		lblNewLabel_9_2.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\user_experience_8h1od462kf5h_32.png"));
		lblNewLabel_9_2.setBounds(12, 267, 40, 33);
		panel_3.add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_9_3 = new JLabel("");
		lblNewLabel_9_3.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\degree_hcro90v93q0y_32.png"));
		lblNewLabel_9_3.setBounds(12, 416, 40, 33);
		panel_3.add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_9_4 = new JLabel("");
		lblNewLabel_9_4.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\skills_mrheq53yz4jj_32.png"));
		lblNewLabel_9_4.setBounds(12, 520, 40, 33);
		panel_3.add(lblNewLabel_9_4);
		
		 cv1_address = new JLabel("New label");
		cv1_address.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cv1_address.setBounds(51, 323, 159, 16);
		panel_3.add(cv1_address);
	}
}
