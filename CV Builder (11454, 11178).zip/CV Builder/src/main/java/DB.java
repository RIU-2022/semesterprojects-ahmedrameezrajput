import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.*;

//public class DB {
//	Connection con=null;
//	java.sql.PreparedStatement pst;
//	public static Connection dbconnect() {
//		try {
//			  
//			  Class.forName("com.mysql.jdbc.Driver");
//			  Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj","root","");
//			  return conn;
//		}
//		catch(Exception e2){
//			System.out.println(e2);
//			return null;
//		 
//		}
//		
//	}
//}

public class DB {
	 
	 
	 // create a function to connect with mysql database
	 
	public static Connection getConnection() throws SQLException, ClassNotFoundException{
//Connection con = DriverManager.getConnection;
Class.forName("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj",
"root", "");
 
return con;
}

	 
	} 