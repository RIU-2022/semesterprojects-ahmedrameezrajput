
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;

public class HEADING extends JFrame {

	private JPanel contentPane;
	public JTextField fname_txf_h;
	public JTextField sname_txf_h;
	public JTextField profession_txf_h;
	public JTextField city_txf_h;
	public JTextField country_txf_h;
	public JTextField phone_txf_h;
	public JTextField email_txf_h;
	public JTextField postal_txf_h;
        public String fname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HEADING frame = new HEADING();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HEADING() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 906, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(192, 192, 192));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(192, 192, 192));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(192, 192, 192));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(192, 192, 192));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(192, 192, 192));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(192, 192, 192));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 61, 892, 670);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("What’s the best way for employers to contact you?");
		lblNewLabel_7.setForeground(SystemColor.textHighlight);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(40, 10, 501, 37);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("We suggest including an email and phone number.");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(50, 43, 310, 28);
		panel_1.add(lblNewLabel_8);
		
		fname_txf_h = new JTextField();
		fname_txf_h.setText("e.g. Asif");
		fname_txf_h.setBounds(40, 137, 262, 37);
		panel_1.add(fname_txf_h);
		fname_txf_h.setColumns(10);
		fname_txf_h.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(fname_txf_h.getText().equals("e.g. Asif"))
				{
					fname_txf_h.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(fname_txf_h.getText().equals(""))
				{
					fname_txf_h.setText("e.g. Asif");
				}
			}
		});
		
		JLabel lblNewLabel_9 = new JLabel("First Name");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9.setBounds(40, 114, 113, 21);
		panel_1.add(lblNewLabel_9);
		
		sname_txf_h = new JTextField();
		sname_txf_h.setText("e.g. Shah");
		sname_txf_h.setColumns(10);
		sname_txf_h.setBounds(333, 137, 262, 37);
		panel_1.add(sname_txf_h);
		sname_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(sname_txf_h.getText().equals("e.g. Shah"))
			{
				sname_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(sname_txf_h.getText().equals(""))
			{
				sname_txf_h.setText("e.g. Shah");
			}
		}
	});
		
		profession_txf_h = new JTextField();
		profession_txf_h.setText("e.g. Accountant");
		profession_txf_h.setColumns(10);
		profession_txf_h.setBounds(40, 227, 555, 37);
		panel_1.add(profession_txf_h);
		profession_txf_h.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(profession_txf_h.getText().equals("e.g. Accountant"))
				{
					profession_txf_h.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(profession_txf_h.getText().equals(""))
				{
					profession_txf_h.setText("e.g. Accountant");
				}
			}
		});
		
		city_txf_h = new JTextField();
		city_txf_h.setText("e.g. Lahore");
		city_txf_h.setColumns(10);
		city_txf_h.setBounds(40, 322, 262, 37);
		panel_1.add(city_txf_h);
		city_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(city_txf_h.getText().equals("e.g. Lahore"))
			{
				city_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(city_txf_h.getText().equals(""))
			{
				city_txf_h.setText("e.g. Lahore");
			}
		}
	});
		
		country_txf_h = new JTextField();
		country_txf_h.setText("e.g. Pakistan");
		country_txf_h.setColumns(10);
		country_txf_h.setBounds(333, 322, 123, 37);
		panel_1.add(country_txf_h);
		country_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(country_txf_h.getText().equals("e.g. Pakistan"))
			{
				country_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(country_txf_h.getText().equals(""))
			{
				country_txf_h.setText("e.g. Pakistan");
			}
		}
	});
		
		phone_txf_h = new JTextField();
		phone_txf_h.setToolTipText("e.g. 03338759360");
		phone_txf_h.setColumns(10);
		phone_txf_h.setBounds(40, 401, 262, 37);
		panel_1.add(phone_txf_h);
		phone_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(phone_txf_h.getText().equals("e.g. 03338759360"))
			{
				phone_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(phone_txf_h.getText().equals(""))
			{
				phone_txf_h.setText("e.g. 03338759360");
			}
		}
	});
		
		email_txf_h = new JTextField();
		email_txf_h.setToolTipText("e.g. khan123@gmail.com");
		email_txf_h.setColumns(10);
		email_txf_h.setBounds(333, 401, 262, 37);
		panel_1.add(email_txf_h);
		email_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(email_txf_h.getText().equals("e.g. khan123@gmail.com"))
			{
				email_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(email_txf_h.getText().equals(""))
			{
				email_txf_h.setText("e.g. khan123@gmail.com");
			}
		}
	});
		
		JLabel lblNewLabel_9_1 = new JLabel("Profession");
		lblNewLabel_9_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1.setBounds(40, 206, 113, 21);
		panel_1.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("City/Municiplaty");
		lblNewLabel_9_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_2.setBounds(40, 302, 113, 21);
		panel_1.add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_9_3 = new JLabel("Phone");
		lblNewLabel_9_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_3.setBounds(40, 383, 113, 21);
		panel_1.add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_9_4 = new JLabel("Country");
		lblNewLabel_9_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_4.setBounds(333, 302, 113, 21);
		panel_1.add(lblNewLabel_9_4);
		
		JLabel lblNewLabel_9_5 = new JLabel("Email");
		lblNewLabel_9_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_5.setBounds(333, 383, 113, 21);
		panel_1.add(lblNewLabel_9_5);
		
		postal_txf_h = new JTextField();
		postal_txf_h.setText("e.g. 460000");
		postal_txf_h.setColumns(10);
		postal_txf_h.setBounds(472, 322, 123, 37);
		panel_1.add(postal_txf_h);
		postal_txf_h.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent e) {
			if(postal_txf_h.getText().equals("e.g. 460000"))
			{
				postal_txf_h.setText("");
			}
		}
		@Override
		public void focusLost(FocusEvent e) {
			if(postal_txf_h.getText().equals(""))
			{
				postal_txf_h.setText("e.g. 460000");
			}
		}
	});
		
		JLabel lblNewLabel_9_4_1 = new JLabel("Postal Code");
		lblNewLabel_9_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_4_1.setBounds(471, 302, 113, 21);
		panel_1.add(lblNewLabel_9_4_1);
		
		JLabel lblNewLabel_9_4_2 = new JLabel("Surname");
		lblNewLabel_9_4_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_4_2.setBounds(333, 114, 113, 21);
		panel_1.add(lblNewLabel_9_4_2);
		
		JButton back_bt_h = new JButton("BACK");
		back_bt_h.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Home1 home1=new Home1();
				home1.setVisible(true);
				dispose();
			}
		});
		back_bt_h.setForeground(SystemColor.textHighlight);
		back_bt_h.setBackground(new Color(255, 255, 255));
		back_bt_h.setBounds(40, 597, 96, 52);
		panel_1.add(back_bt_h);
		
		JButton next_bt_h = new JButton("NEXT: WORK HISTORY");
		next_bt_h.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Home1 h=new Home1();
//				System.out.println("CV:"+h.CV);
				String name,prof,address,phone,email;
				name=fname_txf_h.getText()+" "+sname_txf_h.getText();
				prof=profession_txf_h.getText();
				address=city_txf_h.getText()+"/"+postal_txf_h.getText()+" "+country_txf_h.getText();
				phone=phone_txf_h.getText();
				email=email_txf_h.getText();
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("Insert INTO heading(name,profession,address,phone,email) values(?,?,?,?,?)");
							pst.setString(1, name);
							pst.setString(2, prof);
							pst.setString(3, address);
							pst.setString(4, phone);
							pst.setString(5, email);
							
							pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Added");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				 
				WORKHISTORY workhistory=new WORKHISTORY();
				workhistory.setVisible(true);
				dispose();
				
				
			}
		});
		next_bt_h.setBackground(new Color(220, 20, 60));
		next_bt_h.setForeground(new Color(255, 255, 255));
		next_bt_h.setBounds(640, 612, 223, 37);
		panel_1.add(next_bt_h);
	}
}
