import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SKILLS extends JFrame {

	private JPanel contentPane;
	private JTextField skill1_txf_s;
	private JTextField skill3_txf_s;
	private JTextField skill4_txf_s;
	private JTextField skill2_txf_s;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SKILLS frame = new SKILLS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SKILLS() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 904, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(192, 192, 192));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(192, 192, 192));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 62, 892, 669);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("What skills would you like to highlight?");
		lblNewLabel_7.setForeground(SystemColor.textHighlight);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(129, 36, 439, 53);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("SKILL.1");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8.setBounds(129, 132, 120, 45);
		panel_1.add(lblNewLabel_8);
		
		JLabel lblNewLabel_8_1 = new JLabel("SKILL.2");
		lblNewLabel_8_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8_1.setBounds(129, 222, 120, 45);
		panel_1.add(lblNewLabel_8_1);
		
		JLabel lblNewLabel_8_2 = new JLabel("SKILL.3");
		lblNewLabel_8_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8_2.setBounds(129, 316, 120, 45);
		panel_1.add(lblNewLabel_8_2);
		
		JLabel lblNewLabel_8_3 = new JLabel("SKILL.4");
		lblNewLabel_8_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8_3.setBounds(129, 407, 120, 45);
		panel_1.add(lblNewLabel_8_3);
		
		skill1_txf_s = new JTextField();
		skill1_txf_s.setText("e.g. Andriode App Developer");
		skill1_txf_s.setBounds(263, 134, 305, 45);
		panel_1.add(skill1_txf_s);
		skill1_txf_s.setColumns(10);
		skill1_txf_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(skill1_txf_s.getText().equals("e.g. Andriode App Developer"))
				{
					skill1_txf_s.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(skill1_txf_s.getText().equals(""))
				{
					skill1_txf_s.setText("e.g. Andriode App Developer");
				}
			}
		});
		
		skill3_txf_s = new JTextField();
		skill3_txf_s.setText("e.g. Andriode App Developer");
		skill3_txf_s.setColumns(10);
		skill3_txf_s.setBounds(263, 318, 305, 45);
		panel_1.add(skill3_txf_s);
		skill3_txf_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(skill3_txf_s.getText().equals("e.g. Andriode App Developer"))
				{
					skill3_txf_s.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(skill3_txf_s.getText().equals(""))
				{
					skill3_txf_s.setText("e.g. Andriode App Developer");
				}
			}
		});
		
		skill4_txf_s = new JTextField();
		skill4_txf_s.setText("e.g. Andriode App Developer");
		skill4_txf_s.setColumns(10);
		skill4_txf_s.setBounds(263, 407, 305, 45);
		panel_1.add(skill4_txf_s);
		skill4_txf_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(skill4_txf_s.getText().equals("e.g. Andriode App Developer"))
				{
					skill4_txf_s.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(skill4_txf_s.getText().equals(""))
				{
					skill4_txf_s.setText("e.g. Andriode App Developer");
				}
			}
		});
		
		skill2_txf_s = new JTextField();
		skill2_txf_s.setText("e.g. Andriode App Developer");
		skill2_txf_s.setColumns(10);
		skill2_txf_s.setBounds(263, 222, 305, 45);
		panel_1.add(skill2_txf_s);
		skill2_txf_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(skill2_txf_s.getText().equals("e.g. Andriode App Developer"))
				{
					skill2_txf_s.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(skill2_txf_s.getText().equals(""))
				{
					skill2_txf_s.setText("e.g. Andriode App Developer");
				}
			}
		});
		
		JButton next_bt_s = new JButton("NEXT");
		next_bt_s.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String skill1,skill2,skill3,skill4;
				
				skill1=skill1_txf_s.getText();
				skill2=skill2_txf_s.getText();
				skill3=skill3_txf_s.getText();
				skill4=skill4_txf_s.getText();
				
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("Insert INTO skill(skill1,skill2,skill3,skill4) values(?,?,?,?)");
							pst.setString(1, skill1);
							pst.setString(2, skill2);
							pst.setString(3, skill3);
							pst.setString(4, skill4);
							
							pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Added");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				SUMMARY summary=new SUMMARY();
				summary.setVisible(true);
				dispose();
			}
		});
		next_bt_s.setForeground(Color.WHITE);
		next_bt_s.setBackground(new Color(220, 20, 60));
		next_bt_s.setBounds(626, 554, 181, 46);
		panel_1.add(next_bt_s);
		
		JButton back_bt_s = new JButton("BACK");
		back_bt_s.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("DELETE FROM education");
							
							
							pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Deleted");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				EDUCATION education=new EDUCATION();
				education.setVisible(true);
				dispose();
			}
		});
		back_bt_s.setForeground(SystemColor.textHighlight);
		back_bt_s.setFont(new Font("Tahoma", Font.PLAIN, 10));
		back_bt_s.setBackground(Color.WHITE);
		back_bt_s.setBounds(129, 554, 170, 46);
		panel_1.add(back_bt_s);
		
		
	}
}
