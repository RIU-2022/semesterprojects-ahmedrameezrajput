import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionEvent;
import com.toedter.components.JSpinField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.border.LineBorder;
import javax.swing.JTextPane;

public class WORKHISTORY extends JFrame {

	private JPanel contentPane;
	private JTextField jobtitle_txf_w;
	private JTextField employer_txf_w;
	private JTextField city_txf_w;
	private JTextField country_txf_w;
	JDateChooser sdate_txf_w;
	JDateChooser edate_txf_w ;
	private JTextPane exptextPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WORKHISTORY frame = new WORKHISTORY();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WORKHISTORY() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 905, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setToolTipText("");
		panel_1.setForeground(new Color(192, 192, 192));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 61, 892, 670);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("Tell us about your most recent job");
		lblNewLabel_7.setForeground(SystemColor.textHighlight);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(40, 10, 501, 37);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("We’ll start there and work backward.");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(40, 42, 310, 28);
		panel_1.add(lblNewLabel_8);
		
		jobtitle_txf_w = new JTextField();
		jobtitle_txf_w.setText("e.g. Manager");
		jobtitle_txf_w.setBorder(new LineBorder(new Color(128, 0, 128)));
		jobtitle_txf_w.setBounds(40, 140, 376, 37);
		panel_1.add(jobtitle_txf_w);
		jobtitle_txf_w.setColumns(10);
		jobtitle_txf_w.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(jobtitle_txf_w.getText().equals("e.g. Manager"))
				{
					jobtitle_txf_w.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(jobtitle_txf_w.getText().equals(""))
				{
					jobtitle_txf_w.setText("e.g. Manager");
				}
			}
		});
		
		
		employer_txf_w = new JTextField();
		employer_txf_w.setText("e.g. Etech");
		employer_txf_w.setColumns(10);
		employer_txf_w.setBounds(437, 140, 376, 37);
		panel_1.add(employer_txf_w);
		employer_txf_w.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(employer_txf_w.getText().equals("e.g. Etech"))
				{
					employer_txf_w.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(employer_txf_w.getText().equals(""))
				{
					employer_txf_w.setText("e.g. Etech");
				}
			}
		});
		
		
		city_txf_w = new JTextField();
		city_txf_w.setText("e.g. Lahore");
		city_txf_w.setColumns(10);
		city_txf_w.setBounds(40, 232, 376, 37);
		panel_1.add(city_txf_w);
		city_txf_w.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(city_txf_w.getText().equals("e.g. Lahore"))
				{
					city_txf_w.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(city_txf_w.getText().equals(""))
				{
					city_txf_w.setText("e.g. Lahore");
				}
			}
		});
		
		
		country_txf_w = new JTextField();
		country_txf_w.setText("e.g. Pakistan");
		country_txf_w.setColumns(10);
		country_txf_w.setBounds(437, 232, 376, 37);
		panel_1.add(country_txf_w);
		country_txf_w.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(country_txf_w.getText().equals("e.g. Pakistan"))
				{
					country_txf_w.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(country_txf_w.getText().equals(""))
				{
					country_txf_w.setText("e.g. Pakistan");
				}
			}
		});
		
		
		JLabel lblNewLabel_9 = new JLabel("Job title");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9.setBounds(40, 118, 95, 22);
		panel_1.add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("Employer");
		lblNewLabel_9_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1.setBounds(437, 118, 95, 22);
		panel_1.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_1_1 = new JLabel("City/Municipality");
		lblNewLabel_9_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1_1.setBounds(40, 210, 95, 22);
		panel_1.add(lblNewLabel_9_1_1);
		
		JLabel lblNewLabel_9_1_2 = new JLabel("Country");
		lblNewLabel_9_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1_2.setBounds(437, 210, 95, 22);
		panel_1.add(lblNewLabel_9_1_2);
		
		JLabel lblNewLabel_9_1_3 = new JLabel("Start Date");
		lblNewLabel_9_1_3.setToolTipText("");
		lblNewLabel_9_1_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1_3.setBounds(40, 306, 95, 22);
		panel_1.add(lblNewLabel_9_1_3);
		
		JLabel lblNewLabel_9_1_4 = new JLabel("End Date");
		lblNewLabel_9_1_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_9_1_4.setBounds(437, 306, 95, 22);
		panel_1.add(lblNewLabel_9_1_4);
		
		JButton next_bt_w = new JButton("NEXT");
		next_bt_w.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String jobtitle,jobaddress,sdate,edate,exp;
				jobtitle=jobtitle_txf_w.getText();
				jobaddress=employer_txf_w.getText()+", "+ city_txf_w.getText()+" "+ country_txf_w.getText();
				sdate=((JTextField)sdate_txf_w.getDateEditor().getUiComponent()).getText();
				edate=((JTextField)edate_txf_w.getDateEditor().getUiComponent()).getText();
				exp=exptextPane.getText();
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("Insert INTO experience(jobtitle,jobaddress,sdate,edate,exp) values(?,?,?,?,?)");
							pst.setString(1, jobtitle);
							pst.setString(2, jobaddress);
							pst.setString(3, sdate);
							pst.setString(4, edate);
							pst.setString(5, exp);
							
							pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Added");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				EDUCATION education=new EDUCATION();
				education.setVisible(true);
				dispose();
			}
		});
		next_bt_w.setForeground(new Color(255, 255, 255));
		next_bt_w.setBackground(new Color(220, 20, 60));
		next_bt_w.setBounds(695, 556, 118, 46);
		panel_1.add(next_bt_w);
		
		JButton back_bt_w = new JButton("BACK");
		back_bt_w.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("DELETE FROM heading");
							
							
							pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Deleted");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				HEADING heading=new HEADING();
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("DELETE FROM heading");
							
							
							pst.executeUpdate();
							
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				heading.setVisible(true);
				
				dispose();
			}
		});
		back_bt_w.setBackground(new Color(255, 255, 255));
		back_bt_w.setForeground(SystemColor.textHighlight);
		back_bt_w.setBounds(57, 556, 118, 46);
		panel_1.add(back_bt_w);
		
		 sdate_txf_w = new JDateChooser();
		 sdate_txf_w.setDateFormatString("yyyy-MM-dd");
		sdate_txf_w.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		sdate_txf_w.setBounds(40, 330, 376, 37);
		panel_1.add(sdate_txf_w);
		
		 edate_txf_w = new JDateChooser();
		 edate_txf_w.setDateFormatString("yyyy-MM-dd");
		edate_txf_w.setBounds(437, 330, 376, 37);
		panel_1.add(edate_txf_w);
		
		JLabel lblNewLabel_10 = new JLabel("<html>\r\nBrief Your<br>\r\n Experience\r\n</html>");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_10.setBounds(40, 420, 160, 37);
		panel_1.add(lblNewLabel_10);
		
	    exptextPane = new JTextPane();
		exptextPane.setBounds(187, 404, 463, 122);
		panel_1.add(exptextPane);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(192, 192, 192));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(192, 192, 192));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(192, 192, 192));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(192, 192, 192));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
	}
}
