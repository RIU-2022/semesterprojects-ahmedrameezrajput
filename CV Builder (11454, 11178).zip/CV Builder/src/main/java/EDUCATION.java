import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JMenu;
import javax.swing.JSeparator;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class EDUCATION extends JFrame {

	private JPanel contentPane;
	private JTextField schname_txf_e;
	private JTextField schlocation_txf_e;
	private JComboBox degree_txf_e;
	private JTextField studyfield_txf_e;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EDUCATION frame = new EDUCATION();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EDUCATION() {
		setTitle("CV Buider");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 904, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(192, 192, 192));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(192, 192, 192));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(192, 192, 192));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(0, 0, 0));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 61, 892, 670);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("Tell us about your education");
		lblNewLabel_7.setForeground(SystemColor.textHighlight);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(40, 10, 501, 37);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Include every school, even if you're still there or didn't graduate.");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(40, 43, 357, 28);
		panel_1.add(lblNewLabel_8);
		
		schname_txf_e = new JTextField();
		schname_txf_e.setText("e.g. Riphah university");
		schname_txf_e.setColumns(10);
		schname_txf_e.setBounds(40, 142, 376, 37);
		panel_1.add(schname_txf_e);
		schname_txf_e.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(schname_txf_e.getText().equals("e.g. Riphah university"))
				{
					schname_txf_e.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(schname_txf_e.getText().equals(""))
				{
					schname_txf_e.setText("e.g. Riphah university");
				}
			}
		});
		
		schlocation_txf_e = new JTextField();
		schlocation_txf_e.setText("I-14/2 rwp Pakistan");
		schlocation_txf_e.setToolTipText("");
		schlocation_txf_e.setColumns(10);
		schlocation_txf_e.setBounds(444, 142, 376, 37);
		panel_1.add(schlocation_txf_e);
		schlocation_txf_e.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(schlocation_txf_e.getText().equals("I-14/2 rwp Pakistan"))
				{
					schlocation_txf_e.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(schlocation_txf_e.getText().equals(""))
				{
					schlocation_txf_e.setText("I-14/2 rwp Pakistan");
				}
			}
		});
		
		studyfield_txf_e = new JTextField();
		studyfield_txf_e.setText("e.g. Computer science");
		studyfield_txf_e.setToolTipText("");
		studyfield_txf_e.setColumns(10);
		studyfield_txf_e.setBounds(40, 386, 376, 37);
		panel_1.add(studyfield_txf_e);
		studyfield_txf_e.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(studyfield_txf_e.getText().equals("e.g. Computer science"))
				{
					studyfield_txf_e.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(studyfield_txf_e.getText().equals(""))
				{
					studyfield_txf_e.setText("e.g. Computer science");
				}
			}
		});
		
		JDateChooser gstartdate_txf_e = new JDateChooser();
		gstartdate_txf_e.setDateFormatString("yyyy-MM-dd");
		gstartdate_txf_e.setBounds(444, 386, 179, 37);
		panel_1.add(gstartdate_txf_e);
		
		JDateChooser genddate_txf_e = new JDateChooser();
		genddate_txf_e.setDateFormatString("yyyy-MM-dd");
		genddate_txf_e.setBounds(641, 386, 179, 37);
		panel_1.add(genddate_txf_e);
		
		JButton back_bt_w = new JButton("BACK");
		back_bt_w.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("DELETE FROM experience");
							
							
							pst.executeUpdate();
							
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				WORKHISTORY workhistory=new WORKHISTORY();
				workhistory.setVisible(true);
				dispose();
			}
		});
		back_bt_w.setFont(new Font("Tahoma", Font.PLAIN, 10));
		back_bt_w.setForeground(SystemColor.textHighlight);
		back_bt_w.setBackground(Color.WHITE);
		back_bt_w.setBounds(40, 578, 118, 46);
		panel_1.add(back_bt_w);
		
		JButton next_bt_w = new JButton("NEXT");
		next_bt_w.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String degree,school,sdate,edate;
				
				degree=degree_txf_e.getSelectedItem().toString()+", "+schlocation_txf_e.getText();
				school=schname_txf_e.getText()+""+schlocation_txf_e.getText();
				sdate=((JTextField)gstartdate_txf_e.getDateEditor().getUiComponent()).getText();
				edate=((JTextField)genddate_txf_e.getDateEditor().getUiComponent()).getText();
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("Insert INTO education(degree,school,startdate,enddate) values(?,?,?,?)");
							pst.setString(1, degree);
							pst.setString(2, school);
							pst.setString(3, sdate);
							pst.setString(4, edate);
							
						    pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Added");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				 
				SKILLS skills=new SKILLS();
				skills.setVisible(true);
				dispose();
			}
		});
		next_bt_w.setForeground(Color.WHITE);
		next_bt_w.setBackground(new Color(220, 20, 60));
		next_bt_w.setBounds(702, 578, 118, 46);
		panel_1.add(next_bt_w);
		
		JLabel lblNewLabel_9 = new JLabel("School Name");
		lblNewLabel_9.setBounds(40, 119, 107, 22);
		panel_1.add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("School Location");
		lblNewLabel_9_1.setBounds(444, 119, 107, 22);
		panel_1.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("Degree");
		lblNewLabel_9_2.setBounds(40, 237, 107, 22);
		panel_1.add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_9_3 = new JLabel("Field of Study");
		lblNewLabel_9_3.setBounds(40, 366, 107, 22);
		panel_1.add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_9_4 = new JLabel("Graduation Start Date");
		lblNewLabel_9_4.setBounds(444, 366, 124, 22);
		panel_1.add(lblNewLabel_9_4);
		
		JLabel lblNewLabel_9_5 = new JLabel("Garduation End date");
		lblNewLabel_9_5.setBounds(641, 366, 130, 22);
		panel_1.add(lblNewLabel_9_5);
		
		degree_txf_e = new JComboBox();
		degree_txf_e.setEditable(true);
		degree_txf_e.setModel(new DefaultComboBoxModel(new String[] {"Matric", "FSC", "BCom", "BSSC", "BSSE"}));
		degree_txf_e.setMaximumRowCount(10);
		degree_txf_e.setBounds(40, 259, 376, 37);
		panel_1.add(degree_txf_e);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
