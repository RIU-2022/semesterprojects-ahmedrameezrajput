
//import java.io.File;
//import java.io.IOException;
//import java.net.PasswordAuthentication;
//import java.util.Properties;
//import java.util.Scanner;
//
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.Multipart;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
//
//public class Mail {
//	
//	void sendmail(){
//
//		final String from = "asifshah55111@gmail.com";
//		final String password = "Khan2064&15";
//			String to = "fisakhan0347@gmail.com";
//					//To;
//
//			System.out.println("sending mail....");
//
//			Properties prop = new Properties();
//			prop.put("mail.smtp.host", "smtp.gmail.com");
//			prop.put("mail.smtp.port", "465");
//			prop.put("mail.smtp.auth", "true");
//			prop.put("mail.smtp.socketFactory.port", "465");
//			prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
//
//			Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
//				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
//					return new javax.mail.PasswordAuthentication(from, password);
//				}
//			});
//
//			try {
//
//				Message message = new MimeMessage(session);
//				message.setFrom(new InternetAddress(from));
//				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
//				message.setSubject("testing java mail code");
//
//				String msg = "testing java mail code";
//
//				MimeBodyPart mimeBodyPart = new MimeBodyPart();
//				mimeBodyPart.setContent(msg, "text/html");
//
//				Multipart multipart = new MimeMultipart();
//				multipart.addBodyPart(mimeBodyPart);
//
//				MimeBodyPart attachmentBodyPart = new MimeBodyPart();
//				try {
//					attachmentBodyPart.attachFile(new File(
//							"C:/Users/Asif%20Shah/eclipse-workspace/AcpSemProj/images/cv1.JPG"));
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				multipart.addBodyPart(attachmentBodyPart);
//				message.setContent(multipart);
//
//				Transport.send(message);
//
//				System.out.println("Mail successfully sent..");
//
//			} catch (MessagingException e) {
//				e.printStackTrace();
//			}
//		}
//
//}

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
    public static void main(String[] args) {
        // Recipient's email ID needs to be mentioned.
        String to = "asifshah55111@gmail.com";

        // Sender's email ID needs to be mentioned
        String from = "fisakhan0347@gmail.com";

        // Assuming you are sending email from localhost
        String host = "localhost";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("mail.smtp.host", host);

        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties);

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // Set Subject: header field
            message.setSubject("This is the Subject Line!");

            // Now set the actual message
            message.setText("This is actual message");

            // Send message
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (AddressException ae) {
            ae.printStackTrace();
        } catch (MessagingException me) {
            me.printStackTrace();
        }
    }
}












