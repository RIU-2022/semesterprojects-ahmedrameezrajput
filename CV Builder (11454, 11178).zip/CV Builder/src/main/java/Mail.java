import java.io.File;
import java.io.IOException;
import java.net.PasswordAuthentication;
import java.util.Properties;
import java.util.Scanner;

import javax.mail.Message;
//import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

@SuppressWarnings("unused")
public class Mail {
	
	void sendmail(String To, String name){

		final String from = "11178@students.riphah.edu.pk";
		final String password = "p@swoordRG";
			String to =To;
					//To;

			System.out.println("sending mail....");

			Properties prop = new Properties();
			prop.put("mail.smtp.host", "smtp.gmail.com");
			prop.put("mail.smtp.port", "465");
			prop.put("mail.smtp.auth", "true");
			prop.put("mail.smtp.socketFactory.port", "465");
			prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

			Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
					return new javax.mail.PasswordAuthentication(from, password);
				}
			});

			try {

				Message message = new MimeMessage(session);
				message.setFrom(new InternetAddress(from));
				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
				message.setSubject("testing java mail code");

				String msg = "Welcome "+name+ " to the only CV builder you will ever need. Hope you enjoy the product.";

				MimeBodyPart mimeBodyPart = new MimeBodyPart();
				mimeBodyPart.setContent(msg, "text/html");

				Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(mimeBodyPart);

				//MimeBodyPart attachmentBodyPart = new MimeBodyPart();
//				try {
//					attachmentBodyPart.attachFile(new File("H:\\javapdf"));
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
				//multipart.addBodyPart(attachmentBodyPart);
				message.setContent(multipart);

				Transport.send(message);

				System.out.println("Mail successfully sent..");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

}











