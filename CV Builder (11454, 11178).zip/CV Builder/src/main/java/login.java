import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DropMode;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField email;
	private JPasswordField password_fd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setBackground(SystemColor.inactiveCaption);
		setPreferredSize(new Dimension(400, 300));
		setTitle("CV Builder");
		//setUndecorated(true);
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Asif Shah\\Pictures\\w1.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 940, 713);
		contentPane = new JPanel();
		contentPane.setMinimumSize(new Dimension(32767, 32767));
		contentPane.setToolTipText("");
		contentPane.setBackground(new Color(245, 245, 245));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(234, 78, 465, 513);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 405, 465, 108);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton forgot_btn = new JButton("forgot Your Password");
		forgot_btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				forgetPassword fpass=new forgetPassword();
				fpass.setVisible(true);
			}
		});
		forgot_btn.setBorderPainted(false);
		forgot_btn.setBorder(null);
		forgot_btn.setForeground(SystemColor.textHighlight);
		forgot_btn.setBackground(new Color(255, 255, 255));
		forgot_btn.setBounds(135, 10, 178, 32);
		panel_1.add(forgot_btn);
		
		JLabel lblNewLabel_2 = new JLabel("Don't Have an Account?");
		lblNewLabel_2.setBounds(115, 52, 144, 32);
		panel_1.add(lblNewLabel_2);
		
		JButton signup_btn = new JButton("Sign Up");
		signup_btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SignUp signup=new SignUp();
				signup.setVisible(true);
				dispose();
			}
		});
		signup_btn.setBackground(new Color(255, 255, 255));
		signup_btn.setBorder(null);
		signup_btn.setForeground(SystemColor.textHighlight);
		signup_btn.setBounds(245, 52, 67, 32);
		panel_1.add(signup_btn);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setForeground(SystemColor.textHighlight);
		lblNewLabel_1.setBounds(0, 0, 465, 108);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		
		email = new JTextField();
		email.setText("Email Address");
		email.setBounds(40, 154, 385, 51);
		panel.add(email);
		email.setColumns(10);
		email.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(email.getText().equals("Email Address"))
				{
					email.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(email.getText().equals(""))
				{
					email.setText("Email Address");
				}
			}
		});
		
		JButton sign_in_bt = new JButton("SIGN IN");
		sign_in_bt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String mail=email.getText();
				//System.out.println(mail);
				String pass=String.valueOf(password_fd.getPassword());
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
				
				 try {
					    
						pst=con.prepareStatement(" SELECT * FROM login WHERE email=? and password=? ");
						pst.setString(1, mail);
						pst.setString(2, pass);
						rs=pst.executeQuery();
						if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Logged In");
						String m="fisakhan0347@gmail.com";

						//Mail ma=new Mail();
						//ma.sendmail();
						Home home=new Home();
						home.setVisible(true);
						dispose();
						}
						else {
							
							JOptionPane.showMessageDialog(null, "UserName Or Password Invalid!.");
						}
						
						
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				 
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
			}
		});
		sign_in_bt.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		sign_in_bt.setForeground(new Color(255, 255, 255));
		sign_in_bt.setBackground(new Color(220, 20, 60));
		sign_in_bt.setBounds(41, 309, 384, 51);
		panel.add(sign_in_bt);
		
		password_fd = new JPasswordField();
		password_fd.setToolTipText("Enter Password");
		password_fd.setText("Enter Password");
		password_fd.addFocusListener(new FocusAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void focusGained(FocusEvent e) {
				if(password_fd.getText().equals("Enter Password"))
				{
					password_fd.setText("");
				}
			}
			@SuppressWarnings("deprecation")
			@Override
			public void focusLost(FocusEvent e) {
				if(password_fd.getText().equals(""))
				{
					password_fd.setText("Enter Password");
				}
			}
		});
		password_fd.setBounds(40, 231, 385, 51);
		panel.add(password_fd);
		
		JLabel lblNewLabel_3 = new JLabel("Sign-in to Your Account");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_3.setBounds(114, 113, 178, 31);
		panel.add(lblNewLabel_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(0, 0, 0));
		scrollPane.setBounds(0, 261, 436, -235);
		contentPane.add(scrollPane);
	}
	public JTextField getEmail() {
		return email;
	}
}
