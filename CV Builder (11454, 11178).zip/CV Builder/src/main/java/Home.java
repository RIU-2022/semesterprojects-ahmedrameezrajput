import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.border.BevelBorder;
import javax.swing.UIManager;
import java.awt.Cursor;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setMaximumSize(new Dimension(2147483550, 2147483647));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 906, 770);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 10, 891, 721);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, -13, 891, 119);
		panel.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 106, 891, 615);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setBackground(new Color(0, 0, 128));
		lblNewLabel.setBounds(0, 0, 891, 527);
		ImageIcon icon=new ImageIcon("C:\\Users\\Asif Shah\\Pictures\\home.JPG");
		Image img=icon.getImage();
		Image imgscale=img.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaleicon=new ImageIcon(imgscale);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBorder(new CompoundBorder());
		panel_3.setBounds(285, 285, 326, 73);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel create_bt_h = new JLabel("");
		create_bt_h.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HEADING heading=new HEADING();
				heading.setVisible(true);
				dispose();
			}
		});
		create_bt_h.setBackground(new Color(255, 255, 255));
		create_bt_h.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\button.png"));
		create_bt_h.setHorizontalAlignment(SwingConstants.CENTER);
		create_bt_h.setBounds(0, 0, 291, 46);
		panel_3.add(create_bt_h);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(255, 255, 255));
		panel_4.setBounds(252, 162, 57, 44);
		panel_2.add(panel_4);
		lblNewLabel.setIcon(scaleicon);
		panel_2.add(lblNewLabel);
	}
}
