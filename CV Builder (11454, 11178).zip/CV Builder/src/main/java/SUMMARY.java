import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JFormattedTextField;
import javax.swing.JSlider;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import javax.swing.DropMode;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SUMMARY extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SUMMARY frame = new SUMMARY();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SUMMARY() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 904, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 892, 62);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("2");
		lblNewLabel_6.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6.setForeground(new Color(0, 128, 0));
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(408, 28, 23, 16);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel = new JLabel("HEADING");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(350, 21, 59, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORK HISTORY");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setBounds(429, 21, 84, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EDUCATION");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(532, 21, 59, 31);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SKILLS");
		lblNewLabel_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_3.setBounds(623, 21, 59, 31);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SUMMARY");
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_4.setBounds(714, 21, 59, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("FINALIZE");
		lblNewLabel_5.setForeground(new Color(192, 192, 192));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_5.setBounds(805, 21, 59, 31);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6_1 = new JLabel("1");
		lblNewLabel_6_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_1.setBackground(Color.BLACK);
		lblNewLabel_6_1.setBounds(329, 28, 23, 16);
		panel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel("3");
		lblNewLabel_6_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_2.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_2.setBounds(511, 28, 23, 16);
		panel.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel("4");
		lblNewLabel_6_3.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_3.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_3.setBounds(601, 28, 23, 16);
		panel.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel("5");
		lblNewLabel_6_4.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_4.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_4.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_4.setBounds(692, 28, 23, 16);
		panel.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel("6");
		lblNewLabel_6_5.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_5.setForeground(new Color(0, 128, 0));
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_6_5.setBackground(new Color(192, 192, 192));
		lblNewLabel_6_5.setBounds(784, 28, 23, 16);
		panel.add(lblNewLabel_6_5);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 60, 892, 671);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("Briefly tell us about your background");
		lblNewLabel_7.setForeground(SystemColor.textHighlight);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(120, 67, 399, 45);
		panel_1.add(lblNewLabel_7);
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		editorPane.setBounds(120, 137, 546, 342);
		panel_1.add(editorPane);
		
		JButton back_bt_sum = new JButton("BACK");
		back_bt_sum.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  Class.forName("com.mysql.jdbc.Driver");
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  
					  try {
							
							pst= con.prepareStatement("DELETE FROM summary");
							
							
							pst.executeUpdate();
							
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					  
				}
				catch(Exception e2){
					System.out.println(e2);
					//return null;
				 
				}
				
				SKILLS skills=new SKILLS();
				skills.setVisible(true);
				dispose();
			}
		});
		back_bt_sum.setForeground(SystemColor.textHighlight);
		back_bt_sum.setFont(new Font("Tahoma", Font.PLAIN, 10));
		back_bt_sum.setBackground(Color.WHITE);
		back_bt_sum.setBounds(120, 579, 170, 46);
		panel_1.add(back_bt_sum);
		
		JButton next_bt_sum = new JButton("NEXT");
		next_bt_sum.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Home1 home1=new Home1();
				String sumry;
				sumry= editorPane.getText();
 
					  
					  try {
						  Connection con;
							PreparedStatement pst;
							ResultSet rs;
							  Class.forName("com.mysql.jdbc.Driver");
							   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
							  System.out.println("Connected....");
							
							pst= con.prepareStatement("Insert INTO summary(sumry) values(?)");
							pst.setString(1, sumry);
							
						    pst.executeUpdate();
							JOptionPane.showMessageDialog(null, "Record Added");
							
						} catch (SQLException e1) {
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
						}
					  home1.setVisible(true);
					  dispose();
				
				
			}
		});
		next_bt_sum.setForeground(Color.WHITE);
		next_bt_sum.setBackground(new Color(220, 20, 60));
		next_bt_sum.setBounds(634, 579, 181, 46);
		panel_1.add(next_bt_sum);
		
	}
}
