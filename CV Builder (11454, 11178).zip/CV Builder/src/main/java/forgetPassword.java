import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class forgetPassword extends JFrame {

	private JPanel contentPane;
	private JTextField femail_field;
	private JPasswordField fpasswordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					forgetPassword frame = new forgetPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public forgetPassword() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 904, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 890, 731);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(235, 101, 439, 544);
		panel.add(panel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(new Color(211, 211, 211));
		panel_1_1.setBounds(0, 436, 439, 108);
		panel_1.add(panel_1_1);
		panel_1_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Don't Have an Account?");
		lblNewLabel_2.setBounds(115, 52, 144, 32);
		panel_1_1.add(lblNewLabel_2);
		
		JButton signup_btn = new JButton("Sign Up");
		signup_btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SignUp signup=new SignUp();
				signup.setVisible(true);
			}
		});
		signup_btn.setForeground(SystemColor.textHighlight);
		signup_btn.setBorder(null);
		signup_btn.setBackground(Color.WHITE);
		signup_btn.setBounds(245, 52, 67, 32);
		panel_1_1.add(signup_btn);
		
		femail_field = new JTextField();
		femail_field.setColumns(10);
		femail_field.setBounds(28, 156, 385, 51);
		panel_1.add(femail_field);
		
		JButton sign_in_bt = new JButton("Save Password");
		sign_in_bt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String mail=femail_field.getText();
				String pass=String.valueOf(fpasswordField.getPassword());
				
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					  try {
						Class.forName("com.mysql.jdbc.Driver");
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
					  System.out.println("Connected....");
					  System.out.print(pass);
					  
					  
							
							//JOptionPane.showMessageDialog(null, "Email not exist.");
				
						 try {
							    
								pst=con.prepareStatement(" SELECT * FROM login WHERE email=? ");
								pst.setString(1, mail);
								rs=pst.executeQuery();
								if(rs.next()) {
								
									pst=con.prepareStatement("Update login Set password=? WHERE email=? ");
									pst.setString(1, pass);
									pst.setString(2, mail);
									pst.executeUpdate();
									JOptionPane.showMessageDialog(null, "Change Password Successfully");
									
								dispose();
								}
								else {
									
									JOptionPane.showMessageDialog(null, "UserName Invalid!.");
								}
								
								
								
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
				}
				catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			
		});
		sign_in_bt.setForeground(Color.WHITE);
		sign_in_bt.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		sign_in_bt.setBackground(new Color(220, 20, 60));
		sign_in_bt.setBounds(29, 329, 384, 51);
		panel_1.add(sign_in_bt);
		
		fpasswordField = new JPasswordField();
		fpasswordField.setToolTipText("Enter Password");
		fpasswordField.setBounds(28, 246, 385, 51);
		panel_1.add(fpasswordField);
		
		JLabel lblNewLabel_3 = new JLabel("Forget Your Password");
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(115, 91, 178, 31);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("Enter New Password");
		lblNewLabel.setBounds(28, 231, 129, 16);
		panel_1.add(lblNewLabel);
	}
}
