import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

public class Home1 extends JFrame {

	public int CV;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home1 frame = new Home1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home1() {
		// setExtendedState(JFrame.MAXIMIZED_BOTH);
		// setShape(JFrame.CENTER_ALIGNMENT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 924, 765);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 87, 910, 641);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 245, 251);
		ImageIcon icon = new ImageIcon(
				"C:\\\\Users\\\\Asif Shah\\\\eclipse-workspace\\\\AcpSemProj\\\\icons\\\\Capture1.JPG");
		Image img = icon.getImage();
		Image imgscale = img.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaleicon = new ImageIcon(imgscale);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 276, 910, 365);
		panel.add(panel_2);
		panel_2.setLayout(null);

		JLabel cv1 = new JLabel("");
		cv1.setBackground(new Color(0, 0, 0));
		cv1.setBounds(10, 0, 277, 355);
		// cv1.setIcon(new ImageIcon("C:\\Users\\Asif
		// Shah\\eclipse-workspace\\AcpSemProj\\icons\\cv5.JPG"));
		ImageIcon icon1 = new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\images\\cv1.JPG");
		Image img1 = icon1.getImage();
		Image imgscale1 = (img1).getScaledInstance(cv1.getWidth(), cv1.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaleicon1 = new ImageIcon(imgscale1);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255, 80));
		panel_3.setVisible(false);
		panel_3.setBounds(55, 282, 204, 43);
		panel_2.add(panel_3);
		panel_3.setLayout(null);

		JLabel cv1_bt = new JLabel("");
		cv1_bt.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_3.setVisible(true);
			}
		});
		cv1_bt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				cv_1 c1 = new cv_1();

				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected....");

					try {

						pst = con.prepareStatement("Select * from heading");
						rs = pst.executeQuery();

						if (rs.next()) {
							c1.cv1_name_1.setText(rs.getString(2));
							c1.cv1_prof.setText(rs.getString(3));
							c1.cv1_phone.setText(rs.getString(5));
							c1.cv1_email.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added...");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from summary");
						rs = pst.executeQuery();

						if (rs.next()) {
							c1.cv1_summary.setText(rs.getString(2));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from experience");
						rs = pst.executeQuery();

						if (rs.next()) {
							c1.cv1_jobtitle.setText(rs.getString(2));
							c1.cv1_address.setText(rs.getString(3));
							c1.cv1_expSdate.setText(rs.getString(4));
							c1.cv1_expEdate.setText(rs.getString(5));
							c1.cv1_expPane.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from education");
						rs = pst.executeQuery();

						if (rs.next()) {
							c1.cv1_degree.setText(rs.getString(2));
							c1.cv1_schname.setText(rs.getString(3));
							c1.cv1_eduSdate.setText(rs.getString(4));
							c1.cv1_eduEdate.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from  skill");
						rs = pst.executeQuery();

						if (rs.next()) {
							c1.cv1_skill1.setText(rs.getString(2));
							c1.cv1_skill2.setText(rs.getString(3));
							c1.cv1_skill3.setText(rs.getString(4));
							c1.cv1_skill4.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				c1.setVisible(true);
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected");

					try {

						pst = con.prepareStatement("DELETE FROM heading");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM experience");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM education");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM skill");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM summary");
						pst.executeUpdate();

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				dispose();
				// Cv1 completed

			}
		});
		cv1_bt.setHorizontalAlignment(SwingConstants.CENTER);
		cv1_bt.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\button1.png"));
		cv1_bt.setBounds(0, 0, 204, 43);
		panel_3.add(cv1_bt);
		cv1.setIcon(scaleicon1);
		panel_2.add(cv1);

		cv1.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_3.setVisible(true);
				// cv1_bt.setVisible(true);

			}

		});

		cv1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				panel_3.setVisible(false);

			}
		});

		JLabel cv2 = new JLabel("");
		cv2.setBounds(304, 0, 284, 355);
		// cv2.setIcon(new ImageIcon("C:\\Users\\Asif
		// Shah\\eclipse-workspace\\AcpSemProj\\icons\\cv6.JPG"));
		ImageIcon icon2 = new ImageIcon(
				"C:\\\\Users\\\\Asif Shah\\\\eclipse-workspace\\\\AcpSemProj\\\\images\\\\cv2.JPG");
		Image img2 = icon2.getImage();
		Image imgscale2 = (img2).getScaledInstance(cv2.getWidth(), cv2.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaleicon2 = new ImageIcon(imgscale2);

		JPanel panel_4 = new JPanel();
		panel_4.setVisible(false);
		panel_4.setForeground(new Color(255, 255, 255));
		panel_4.setBackground(new Color(255, 255, 255, 80));
		panel_4.setBounds(355, 282, 204, 43);
		panel_2.add(panel_4);
		panel_4.setLayout(null);

		JLabel cv2_bt = new JLabel("");
		cv2_bt.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_4.setVisible(true);
			}
		});

		cv2_bt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				cv_2 c2 = new cv_2();

				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected....");

					try {

						pst = con.prepareStatement("Select * from heading");
						rs = pst.executeQuery();

						if (rs.next()) {
							c2.cv1_name_1.setText(rs.getString(2));
							c2.cv1_prof.setText(rs.getString(3));
							c2.cv1_phone.setText(rs.getString(5));
							c2.cv1_email.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from summary");
						rs = pst.executeQuery();

						if (rs.next()) {
							c2.cv1_summary.setText(rs.getString(2));

							JOptionPane.showMessageDialog(null, "Record Added");
						} else {

						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from experience");
						rs = pst.executeQuery();

						if (rs.next()) {
							c2.cv1_jobtitle.setText(rs.getString(2));
							c2.cv1_address.setText(rs.getString(3));
							c2.cv1_expSdate.setText(rs.getString(4));
							c2.cv1_expEdate.setText(rs.getString(5));
							c2.cv1_expPane.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from education");
						rs = pst.executeQuery();

						if (rs.next()) {
							c2.cv1_degree.setText(rs.getString(2));
							c2.cv1_schname.setText(rs.getString(3));
							c2.cv1_eduSdate.setText(rs.getString(4));
							c2.cv1_eduEdate.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from  skill");
						rs = pst.executeQuery();

						if (rs.next()) {
							c2.cv1_skill1.setText(rs.getString(2));
							c2.cv1_skill2.setText(rs.getString(3));
							c2.cv1_skill3.setText(rs.getString(4));
							c2.cv1_skill4.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				c2.setVisible(true);
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected....");

					try {

						pst = con.prepareStatement("DELETE FROM heading");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM experience");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM education");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM skill");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM summary");
						pst.executeUpdate();

						pst.executeUpdate();

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				dispose();
				// cv2 completed
			}
		});
		cv2_bt.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\button1.png"));
		cv2_bt.setHorizontalAlignment(SwingConstants.CENTER);
		cv2_bt.setBounds(0, 0, 204, 43);
		panel_4.add(cv2_bt);
		cv2.setIcon(scaleicon2);
		panel_2.add(cv2);

		cv2.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_4.setVisible(true);

			}

		});

		cv2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				panel_4.setVisible(false);
				// cv1_bt.setVisible(false);
			}
		});

		JLabel cv3 = new JLabel("");
		cv3.setBounds(607, 0, 293, 355);
		ImageIcon icon3 = new ImageIcon(
				"C:\\\\Users\\\\Asif Shah\\\\eclipse-workspace\\\\AcpSemProj\\\\images\\\\cv3.JPG");
		Image img3 = icon3.getImage();
		Image imgscale3 = (img3).getScaledInstance(cv3.getWidth(), cv3.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon scaleicon3 = new ImageIcon(imgscale3);

		JPanel panel_5 = new JPanel();
		panel_5.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_5.setVisible(true);
			}
		});
		panel_5.setVisible(false);
		panel_5.setBounds(656, 282, 192, 43);
		panel_2.add(panel_5);
		panel_5.setLayout(null);

		JLabel cv3_bt = new JLabel("");
		cv3_bt.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_5.setVisible(true);
			}
		});
		cv3_bt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				cv_3 c3 = new cv_3();

				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected....");

					try {

						pst = con.prepareStatement("Select * from heading");
						rs = pst.executeQuery();

						if (rs.next()) {
							c3.cv1_name_1.setText(rs.getString(2));
							c3.cv1_prof.setText(rs.getString(3));
							c3.cv1_phone.setText(rs.getString(5));
							c3.cv1_email.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from summary");
						rs = pst.executeQuery();

						if (rs.next()) {
							c3.cv1_summary.setText(rs.getString(2));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from experience");
						rs = pst.executeQuery();

						if (rs.next()) {
							c3.cv1_jobtitle.setText(rs.getString(2));
							c3.cv1_address.setText(rs.getString(3));
							c3.cv1_expSdate.setText(rs.getString(4));
							c3.cv1_expEdate.setText(rs.getString(5));
							c3.cv1_expPane.setText(rs.getString(6));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from education");
						rs = pst.executeQuery();

						if (rs.next()) {
							c3.cv1_degree.setText(rs.getString(2));
							c3.cv1_schname.setText(rs.getString(3));
							c3.cv1_eduSdate.setText(rs.getString(4));
							c3.cv1_eduEdate.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					try {

						pst = con.prepareStatement("Select * from  skill");
						rs = pst.executeQuery();

						if (rs.next()) {
							c3.cv1_skill1.setText(rs.getString(2));
							c3.cv1_skill2.setText(rs.getString(3));
							c3.cv1_skill3.setText(rs.getString(4));
							c3.cv1_skill4.setText(rs.getString(5));

						} else {
							System.out.println("NO Record Added");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				c3.setVisible(true);
				try {
					Connection con;
					PreparedStatement pst;
					ResultSet rs;
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1", "root", "");
					System.out.println("Connected....");

					try {

						pst = con.prepareStatement("DELETE FROM heading");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM experience");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM education");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM skill");
						pst.executeUpdate();
						pst = con.prepareStatement("DELETE FROM summary");
						pst.executeUpdate();

						pst.executeUpdate();

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				} catch (Exception e2) {
					System.out.println(e2);
					// return null;

				}
				dispose();
				// cv3 comleted
			}
		});
		cv3_bt.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\button1.png"));
		cv3_bt.setBounds(0, 0, 192, 43);
		panel_5.add(cv3_bt);
		cv3.setIcon(scaleicon3);
		panel_2.add(cv3);
		lblNewLabel.setIcon(scaleicon);
		panel.add(lblNewLabel);

		cv3.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				panel_5.setVisible(true);

			}

		});

		cv3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				panel_5.setVisible(false);
				// cv1_bt.setVisible(false);
			}
		});

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1
				.setIcon(new ImageIcon("C:\\Users\\Asif Shah\\eclipse-workspace\\AcpSemProj\\icons\\Capture2.JPG"));
		lblNewLabel_1.setBounds(665, 0, 245, 251);
//		ImageIcon icon1=new ImageIcon("C:\\\\Users\\\\Asif Shah\\\\eclipse-workspace\\\\AcpSemProj\\\\icons\\\\Capture2.JPG\"");
//		Image img1=icon1.getImage();
//		Image imgscale1=(img1).getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(), Image.SCALE_SMOOTH);
//		ImageIcon scaleicon1=new ImageIcon(imgscale1);
//		lblNewLabel_1.setIcon(scaleicon1);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setVerticalTextPosition(SwingConstants.TOP);
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		String text = "<html>";
		text += "Whether you’re looking for a simple,modern, or creative resume template<br>";
		text += "Zety’s got you covered. Just pick your favourite resume template<br>";
		text += "fill in the details and be ready to apply for your dream job in minutes!<br>";
		lblNewLabel_2.setText(text);
		lblNewLabel_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_2.setLabelFor(this);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(242, 99, 421, 152);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("Resume Templates");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2_1.setBounds(242, 10, 421, 89);
		panel.add(lblNewLabel_2_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(0, 0, 910, 87);
		contentPane.add(panel_1);
	}

	private void resize(Object setAlignmentX) {
		// TODO Auto-generated method stub

	}
}
