import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JPasswordField;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;
import java.awt.Cursor;


public class SignUp extends JFrame {

	private JPanel contentPane;
	private JTextField name_s;
	private JButton signin_s;
	private JPasswordField password_s;
	private JPasswordField confpassword;
	private JTextField email_s;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//Connection con;
	public SignUp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Asif Shah\\Pictures\\w1.jpg"));
		
		login lgin=new login();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 814, 725);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(218, 57, 400, 587);
		contentPane.add(panel);
		panel.setLayout(null);
		
		name_s = new JTextField();
		name_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(name_s.getText().equals("Enter Your Name"))
				{
					name_s.setText("");
				}
				
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(name_s.getText().equals(""))
				{
					name_s.setText("Enter Your Name");
				}
			}
		});
		name_s.setText("Enter Your Name");
		name_s.setBounds(54, 147, 290, 44);
		panel.add(name_s);
		name_s.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Sign Up Your Account");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel.setForeground(SystemColor.textHighlight);
		lblNewLabel.setBounds(99, 84, 199, 34);
		panel.add(lblNewLabel);
		
		JButton signUp_s = new JButton("Sign Up");
		signUp_s.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
                            
                            String Fullname=name_s.getText();
				            String Password=password_s.getText();
				            String cPassword=password_s.getText();
				            String Email=email_s.getText();
				            
                    if(Password.equals(cPassword)) {
                    	
                    	if(Email!=null) {

				            try {
								Connection con;
								PreparedStatement pst;
								ResultSet rs;
								  Class.forName("com.mysql.jdbc.Driver");
								   con= DriverManager.getConnection("jdbc:mysql://localhost:3306/acpsemproj1","root","");
								  System.out.println("Connected....");
								  
								  try {
										
										pst= con.prepareStatement("Insert INTO login(`fullname`, `password`, `cpassword`, `email`) values(?,?,?,?)");
										pst.setString(1, Fullname);
										pst.setString(2, Password);
										pst.setString(3, cPassword);
										pst.setString(4, Email);
										
										pst.executeUpdate();
										JOptionPane.showMessageDialog(null, "Register Successfully");
										
										Mail mail=new Mail();
										mail.sendmail(Email,Fullname);
			
										lgin.setVisible(true);
										dispose();
									} catch (SQLException e1) {
										e1.printStackTrace();
									}
								  
							}
							catch(Exception e2){
								System.out.println(e2);
								//return null;
							 
							}
                    	}
                    	else {
                    		JOptionPane.showMessageDialog(null, "Please Enter Email");
                    	}
  }
  else {
	  JOptionPane.showMessageDialog(null, "Password and ConfPassword are not match");
  }
	  
				
			}
		});
		signUp_s.setForeground(new Color(255, 255, 255));
		signUp_s.setBackground(new Color(139, 0, 0));
		signUp_s.setFont(new Font("Tahoma", Font.PLAIN, 14));
		signUp_s.setBounds(54, 448, 290, 44);
		panel.add(signUp_s);
		
		JLabel lblNewLabel_1 = new JLabel("Already have an Account?");
		lblNewLabel_1.setBounds(80, 502, 148, 25);
		panel.add(lblNewLabel_1);
		
		signin_s = new JButton("Sign in");
		signin_s.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lgin.setVisible(true);
				dispose();
			}
		});
		signin_s.setBorder(null);
		signin_s.setBackground(new Color(255, 255, 255));
		signin_s.setForeground(SystemColor.textHighlight);
		signin_s.setFont(new Font("Tahoma", Font.BOLD, 12));
		signin_s.setBounds(225, 497, 73, 33);
		panel.add(signin_s);
		
		password_s = new JPasswordField();
		password_s.setDragEnabled(true);
		password_s.setDoubleBuffered(true);
		password_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(password_s.getText().equals("Password"))
				{
					password_s.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(password_s.getText().equals(""))
				{
					password_s.setText("Password");
				}
			}
		});
		password_s.setText("Password");
		password_s.setBounds(54, 230, 290, 44);
		panel.add(password_s);
		
		confpassword = new JPasswordField();
		confpassword.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		confpassword.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(confpassword.getText().equals("Password"))
				{
					confpassword.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(confpassword.getText().equals(""))
				{
					confpassword.setText("Password");
				}
			}
		});
		confpassword.setText("Password");
		confpassword.setBounds(54, 313, 290, 44);
		panel.add(confpassword);
		
		email_s = new JTextField();
		email_s.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(email_s.getText().equals("Enter Your Email"))
				{
					email_s.setText("");
				}
				
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(email_s.getText().equals(""))
				{
					email_s.setText("Enter Your Email");
				}
			}
		});
		email_s.setText("Enter Your Email");
		email_s.setColumns(10);
		email_s.setBounds(54, 385, 290, 44);
		panel.add(email_s);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_2.setBounds(54, 211, 99, 25);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Confirm Password");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_2_1.setBounds(54, 292, 116, 25);
		panel.add(lblNewLabel_2_1);
	}
}
